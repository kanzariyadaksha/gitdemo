<?php

return [
    'title_home' => 'Начало',
    'descr_home' => 'Магазин за хранителни добавки',
    'title_products' => 'Продукти',
    'descr_products' => 'Продукти с доказано качество',
    'title_contacts' => 'Контакти',
    'descr_contacts' => 'Пишете ни',
    'title_checkout' => 'Плащане',
    'descr_checkout' => 'Онлайн магазин с поддръжка на paypal, банкови разплащания и наложен платеж',
    'descr_products_category' => 'Хранителни добавки от категория - '
];
