<?php
$stripe = [
    "secret_key"      => "STRIPE_SECRET_KEY",
    "publishable_key" => "STRIPE_PUBLISHABLE_KEY",
];
?>