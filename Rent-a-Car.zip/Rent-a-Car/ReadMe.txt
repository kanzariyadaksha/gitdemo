Title: ONLINE RESERVATION for rent-a-car
Description: This a complete "online-reservation for a rent-a-car business" done in PHP + MySQL. I have done this project last year for a student 

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

www.webdevelopplus.com
