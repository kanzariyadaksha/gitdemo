<div class="navbar-wrapper">
    <nav class="navbar">
        <div class="container">
            <div class="navbar-header">
                <div class="navbar-brand">
                    <a href="/home" class="navbar-brand">
                        {{ $main_company['name'] }}
                        <br>
                        
                    </a>
                </div>
            </div>
            @include('partial.navigation_help')
        </div>
    </nav>
</div>