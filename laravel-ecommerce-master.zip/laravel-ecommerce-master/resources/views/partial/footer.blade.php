<div class="col-md-12 f-footer-area">

    <div class="row footer-row">
        <div class="col-xs-4 col-sm-4 col-md-4">
            <img class="logo-jpg" src="img/pt-default/logo.png">
            
        </div>

        <div class="col-xs-4 col-sm-4 col-md-4 menu">
            <h3 class="widget-title heading-title">Contact Us</h3>
            <div class="line line-30"></div>

        </div>

        <div class="col-xs-4 col-sm-4 col-md-4 newsletter">
            
            <div class="footer-right">
                <h3 class="widget-title heading-title">
                        Сошиал                  </h3>
                <div class="line line-30"></div>
                <ul>
                    <li>
                        <div class="social-icons">
                            <ul>
                                <li class="icon-facebook fa-lg"><a href="https://www.facebook.com/" target="_blank" title="Become our fan"><i class="fa fa-facebook"></i></a>
                                </li>

                                <li class="icon-twitter fa-lg"><a href="http://twitter.com/#" target="_blank" title="Follow us"><i class="fa fa-twitter"></i></a>
                                </li>

                                <li class="icon-google fa-lg"><a href="https://plus.google.com/u/0/#" target="_blank" title="Get updates"><i class="fa fa-google-plus"></i></a>
                                </li>

                                <li class="icon-instagram fa-lg"><a href="https://www.instagram.com/" target="_blank" title="Follow us"><i class="fa fa-instagram"></i></a>
                                </li>                            
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

    </div>

    <div class="fourth-footer-area row ">

        <div id="copy-right" class="copy-right col-sm-12">
            <div class="col-sm-8">
                Copyright ©. 2017 All Right Reserved. Techstar Agency.
            </div>

        </div>
        <!-- end #copyright -->

    </div>

</div>
@section('scripts') @parent

@stop
