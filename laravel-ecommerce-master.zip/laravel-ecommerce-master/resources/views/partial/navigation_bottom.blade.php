<div class="header-bottom-content">
    <div class="col-md-3 col-sm-2 col-xs-12">
       <h3 class="full-category" id="full-category">Бүх ангилал<i class="fa fa-navicon"></i></h3> 
    </div>
    <div class="col-md-9 col-sm-10 col-xs-12">
        <ul class="line-menu">
            <li><a class="kk-1" href="{{ route('home') }}">Нүүр</a></li>
            <li><a class="kk-1" href="{{ route('products') }}">Бүтээгдэхүүний жагсаалт</a></li>
        </ul>
    </div>
</div>
