<?php

return [

    'contact'             => 'Contact Us',
    'name'                => 'Name',
    'email'               => 'Email',
    'message'             => 'Message',
    'name_placeholder'    => 'Type your full name here',
    'email_placeholder'   => 'We need your email to be on touch',
    'message_placeholder' => 'Tell us what we can help you with',
    'contact_us'          => 'Contact Us!',
    'thanks'              => 'Thanks for contacting us! Soon you will receive our response',
    'type_of_request'     => 'Subject heading',

];
