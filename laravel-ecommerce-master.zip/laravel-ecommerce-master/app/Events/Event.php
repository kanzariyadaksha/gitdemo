<?php

namespace app\Events;

abstract class Event
{
    //
}
