# Event-site
helps to register an users for on events conducted in college fests with simple logic with secured way

# Installation

1>Install XAMPP or WAMPP.

2>Open XAMPP Control panal and start [apache] and [mysql] .

3>Download project from github(https://github.com/PuneethReddyHC/event-management.git)  
    OR follow gitbash commands
    
    i>cd C:\\xampp\htdocs\
    
    ii>git clone https://github.com/PuneethReddyHC/event-management.git
    
4>extract files in C:\\xampp\htdocs\.

5> open link localhost/phpmyadmin

6>click on new at side navbar.

7>give a database name as (eventsite) hit on create button.

8>after creating database name click on import.

9>browse the file in directory[Event-site/db/event-management.sql].

10>after importing successfully.

11>open any browser and type http://localhost/event-management-master.

12>first register and then login

13>admin login details  Email=admin@gmail.com and Password=123456789.

## visit my other repository with different admin pages with below link
https://github.com/PuneethReddyHC/online-shopping-system-with-advanced-admin-page

https://github.com/PuneethReddyHC/online-shopping-system-advanced

## Screenshots
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/home.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/events.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/about.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/events1.png)
![Image of adduser](https://github.com/PuneethReddyHC/event-management/blob/master/screenshots/login.png)

##  If you like my project hit a star button
